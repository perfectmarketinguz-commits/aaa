import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Client } from '../types';

export function subscribeToClients(callback: (clients: Client[]) => void) {
  const q = query(collection(db, 'clients'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const clients = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        id: doc.id,
        createdAt: data.createdAt?.toDate?.()?.toLocaleDateString() || data.createdAt || ''
      };
    }) as Client[];
    callback(clients);
  });
}

export async function addClient(client: Omit<Client, 'id' | 'createdAt'>) {
  try {
    await addDoc(collection(db, 'clients'), {
      ...client,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error adding client:', error);
    throw error;
  }
}

export async function deleteClient(id: string) {
  await deleteDoc(doc(db, 'clients', id));
}

// Similar for Deals and Tasks
export function subscribeToDeals(callback: (deals: any[]) => void) {
  const q = query(collection(db, 'deals'), orderBy('updatedAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        id: doc.id,
        updatedAt: data.updatedAt?.toDate?.()?.toLocaleDateString() || data.updatedAt || ''
      };
    }));
  });
}

export async function addDeal(deal: any) {
  await addDoc(collection(db, 'deals'), {
    ...deal,
    updatedAt: serverTimestamp()
  });
}

export function subscribeToTasks(callback: (tasks: any[]) => void) {
  const q = query(collection(db, 'tasks'), orderBy('completed', 'asc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  });
}

export async function toggleTask(id: string, completed: boolean) {
  await updateDoc(doc(db, 'tasks', id), { completed });
}

// User management
export function subscribeToUsers(callback: (users: any[]) => void) {
  const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        id: doc.id,
        createdAt: data.createdAt?.toDate?.()?.toLocaleDateString() || data.createdAt || ''
      };
    }));
  });
}

export async function addUserToDb(userData: { email: string, name: string, role: string }) {
  // Note: This adds to the 'users' collection in Firestore. 
  // Authentication must still happen via Google Login or manual invite.
  await addDoc(collection(db, 'users'), {
    ...userData,
    createdAt: serverTimestamp()
  });
}
