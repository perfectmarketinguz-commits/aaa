import { 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  User 
} from 'firebase/auth';
import { 
  doc, 
  getDoc,
  setDoc,
  serverTimestamp,
  collection,
  query,
  where,
  getDocs,
  limit
} from 'firebase/firestore';
import { auth, db, googleProvider } from '../lib/firebase';

export interface AppUser {
  uid: string;
  email: string;
  displayName: string;
  role: 'admin' | 'staff';
}

export async function signInWithGoogle() {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
}

export async function logout() {
  await signOut(auth);
}

export async function checkUserAuthorization(user: User): Promise<AppUser | null> {
  // 1. Try to find by UID directly
  const userDoc = await getDoc(doc(db, 'users', user.uid));
  
  if (userDoc.exists()) {
    return userDoc.data() as AppUser;
  }

  // 2. If not found by UID, try to find by email (for users added by admin manually)
  if (user.email) {
    const q = query(collection(db, 'users'), where('email', '==', user.email), limit(1));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      const docData = querySnapshot.docs[0].data();
      console.log('Found user by email invitation:', docData);
      
      const userData: AppUser = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || docData.name || 'User',
        role: docData.role || 'staff'
      };

      try {
        // 3. Migrate/Link this user account to their UID for future faster lookups
        await setDoc(doc(db, 'users', user.uid), {
          ...userData,
          linkedAt: serverTimestamp()
        });
        console.log('Successfully linked user UID to account');
      } catch (migrateErr) {
        console.error('Failed to link user UID:', migrateErr);
        // We still return the user data, but some rules might fail if they check for existing doc
      }

      return userData;
    }
    console.log('No user document found for email:', user.email);
  }

  // Bootstrap admin for the specific email mentioned or first user if none exist?
  if (user.email === 'perfectmarketinguz@gmail.com') {
    const adminData: AppUser = {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName || 'Admin',
      role: 'admin'
    };
    await setDoc(doc(db, 'users', user.uid), {
      ...adminData,
      createdAt: serverTimestamp()
    });
    return adminData;
  }

  return null;
}
