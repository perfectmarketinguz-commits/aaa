import React, { useState } from 'react';
import { X } from 'lucide-react';
import { cn } from '../lib/utils';

interface AddClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (client: { 
    name: string, 
    company: string, 
    email: string, 
    status: string,
    pfxData?: string,
    pfxFileName?: string 
  }) => void;
}

export function AddClientModal({ isOpen, onClose, onAdd }: AddClientModalProps) {
  const [formData, setFormData] = useState<{
    name: string;
    company: string;
    email: string;
    status: string;
    pfxData?: string;
    pfxFileName?: string;
  }>({
    name: '',
    company: '',
    email: '',
    status: 'lead'
  });

  const [uploading, setUploading] = useState(false);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if it's a PFX or CRT or something similar if needed, 
    // but the user specifically asked for PFX.
    
    setUploading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setFormData(prev => ({
        ...prev,
        pfxData: base64,
        pfxFileName: file.name
      }));
      setUploading(false);
    };
    reader.onerror = () => {
      alert("Faylni o'qishda xatolik yuz berdi.");
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    setFormData({ name: '', company: '', email: '', status: 'lead' });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-[#2D3025]/40 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <div className="relative bg-[#F5F5F0] w-full max-w-md rounded-[32px] shadow-2xl border border-[#D9D9D0] overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-serif text-[#2D3025]">Yangi Mijoz</h2>
              <p className="text-[#5A5A40] text-sm italic">Ma'lumotlarni kiriting</p>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-[#EAEAE2] rounded-full transition-colors text-[#A89F8E]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">
                F.I.O
              </label>
              <input
                required
                type="text"
                placeholder="Alisher Usmonov"
                className="w-full bg-[#EAEAE2] border-none rounded-2xl px-6 py-3 text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none placeholder:opacity-40 text-[#2D3025]"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">
                Kompaniya
              </label>
              <input
                required
                type="text"
                placeholder="MChJ 'Kelajak'"
                className="w-full bg-[#EAEAE2] border-none rounded-2xl px-6 py-3 text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none placeholder:opacity-40 text-[#2D3025]"
                value={formData.company}
                onChange={e => setFormData({ ...formData, company: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">
                Email Manzili
              </label>
              <input
                required
                type="email"
                placeholder="info@example.com"
                className="w-full bg-[#EAEAE2] border-none rounded-2xl px-6 py-3 text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none placeholder:opacity-40 text-[#2D3025]"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">
                Status
              </label>
              <select
                className="w-full bg-[#EAEAE2] border-none rounded-2xl px-6 py-3 text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none text-[#2D3025] appearance-none cursor-pointer"
                value={formData.status}
                onChange={e => setFormData({ ...formData, status: e.target.value })}
              >
                <option value="lead">Lid</option>
                <option value="active">Faol</option>
                <option value="inactive">Nofaol</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">
                Elektron imzo (PFX)
              </label>
              <div className="relative group">
                <input
                  type="file"
                  accept=".pfx,.p12"
                  className="hidden"
                  id="pfx-upload"
                  onChange={handleFileChange}
                />
                <label 
                  htmlFor="pfx-upload"
                  className={cn(
                    "flex flex-col items-center justify-center w-full min-h-[100px] bg-[#EAEAE2] border-2 border-dashed rounded-2xl cursor-pointer transition-all",
                    formData.pfxFileName ? "border-[#5A5A40] bg-white" : "border-[#D9D9D0] hover:border-[#5A5A40]"
                  )}
                >
                  {uploading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-[#5A5A40]"></div>
                  ) : formData.pfxFileName ? (
                    <div className="text-center px-4">
                      <p className="text-xs font-bold text-[#2D3025] truncate max-w-[200px]">
                        {formData.pfxFileName}
                      </p>
                      <p className="text-[9px] text-[#5A5A40] mt-1 italic">
                        Almashtirish uchun bosing
                      </p>
                    </div>
                  ) : (
                    <div className="text-center">
                      <p className="text-xs text-[#5A5A40]">PFX faylni yuklash</p>
                      <p className="text-[9px] text-[#A89F8E] mt-1 font-medium">Bosing yoki faylni sudrab keling</p>
                    </div>
                  )}
                </label>
              </div>
            </div>

            <div className="pt-4 flex gap-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-white border border-[#D9D9D0] text-[#2D3025] py-3 rounded-full text-sm font-medium hover:bg-[#F5F5F0] transition-all"
              >
                Bekor qilish
              </button>
              <button
                type="submit"
                className="flex-1 bg-[#5A5A40] text-white py-3 rounded-full text-sm font-medium hover:bg-[#454530] transition-all shadow-lg shadow-[#5A5A40]/10"
              >
                Saqlash
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
