import React from 'react';
import { LogIn } from 'lucide-react';
import { signInWithGoogle } from '../services/authService';

interface LoginPageProps {
  error?: string;
}

export function LoginPage({ error }: LoginPageProps) {
  return (
    <div className="min-h-screen bg-[#F5F5F0] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-white p-12 rounded-[48px] shadow-2xl border border-[#D9D9D0] text-center">
        <div className="w-20 h-20 rounded-full bg-[#5A5A40] border border-[#F5F5F0]/20 flex items-center justify-center font-serif italic text-3xl mx-auto mb-8 text-white">
          V
        </div>
        <h1 className="text-4xl font-serif text-[#2D3025] mb-4">UzCRM</h1>
        <p className="text-[#5A5A40] italic mb-12">Iltimos, tizimga kirish uchun Google akkauntingizdan foydalaning.</p>
        
        {error && (
          <div className="mb-8 p-4 bg-rose-50 text-rose-600 rounded-2xl text-sm border border-rose-100">
            {error}
          </div>
        )}

        <button 
          onClick={() => signInWithGoogle()}
          className="w-full bg-[#5A5A40] text-white py-4 rounded-full font-medium flex items-center justify-center gap-3 hover:bg-[#454530] transition-all shadow-lg shadow-[#5A5A40]/10"
        >
          <LogIn className="w-5 h-5" />
          Google bilan kirish
        </button>

        <p className="mt-12 text-[10px] uppercase tracking-widest text-[#A89F8E] font-bold">
          Xavfsiz va Ishonchli Tizim
        </p>
      </div>
    </div>
  );
}
