import { useState } from 'react';
import { 
  Search, 
  Filter, 
  MoreVertical, 
  Plus, 
  Mail, 
  Phone,
  UserPlus,
  Download,
  Key
} from 'lucide-react';
import { Client } from '../types';
import { cn } from '../lib/utils';

interface ClientsProps {
  clients: Client[];
  onAddClick: () => void;
}

export function Clients({ clients, onAddClick }: ClientsProps) {
  const [search, setSearch] = useState('');

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.company.toLowerCase().includes(search.toLowerCase())
  );

  const handleDownloadPfx = (client: Client) => {
    if (!client.pfxData || !client.pfxFileName) return;
    
    const link = document.createElement('a');
    link.href = client.pfxData;
    link.download = client.pfxFileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-serif text-[#2D3025]">Mijozlar Bazasi</h2>
          <p className="text-[#5A5A40] italic">Barcha faol va potensial mijozlar.</p>
        </div>
        <button 
          onClick={onAddClick}
          className="bg-[#5A5A40] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#454530] transition-all flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Yangi mijoz
        </button>
      </div>

      <div className="bg-white rounded-[32px] shadow-sm border border-[#D9D9D0] overflow-hidden">
        <div className="p-6 border-b border-[#F5F5F0] flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A89F8E]" />
            <input 
              type="text" 
              placeholder="Qidiruv..."
              className="w-full pl-11 pr-6 py-2.5 bg-[#EAEAE2] border-none rounded-full text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none transition-all placeholder:opacity-50 text-[#2D3025]"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button className="flex items-center gap-2 px-6 py-2.5 text-[#5A5A40] border border-[#D9D9D0] rounded-full hover:bg-[#F5F5F0] transition-colors text-sm font-medium italic">
            <Filter className="w-4 h-4" />
            Filtrlash
          </button>
        </div>

        <div className="overflow-x-auto p-2">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] uppercase tracking-widest text-[#5A5A40] border-b border-[#F5F5F0]">
                <th className="px-6 py-4 font-semibold tracking-widest">Mijoz Ismi</th>
                <th className="px-6 py-4 font-semibold tracking-widest">Kompaniya</th>
                <th className="px-6 py-4 font-semibold tracking-widest">Holat</th>
                <th className="px-6 py-4 font-semibold tracking-widest">Sana</th>
                <th className="px-6 py-4 font-semibold text-right tracking-widest">Amallar</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {filteredClients.map((client) => (
                <tr key={client.id} className="border-b border-[#F5F5F0] hover:bg-[#F5F5F0]/30 transition-colors group">
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#A89F8E] flex items-center justify-center text-[#2D3025] font-bold text-sm">
                        {client.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-semibold text-[#2D3025]">{client.name}</div>
                        <div className="text-[11px] text-[#A89F8E] tracking-tight">{client.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className="text-[#5A5A40] italic font-medium">{client.company}</span>
                  </td>
                  <td className="px-6 py-5">
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[11px] font-medium",
                      client.status === 'active' ? "bg-green-50 text-green-700" :
                      client.status === 'inactive' ? "bg-orange-50 text-orange-700" :
                      "bg-blue-50 text-blue-700"
                    )}>
                      {client.status === 'active' ? "Faol" : 
                       client.status === 'inactive' ? "Nofaol" : "Lid"}
                    </span>
                  </td>
                  <td className="px-6 py-5">
                    <span className="text-[#A89F8E] font-medium">{client.createdAt}</span>
                  </td>
                  <td className="px-6 py-5 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      {client.pfxData && (
                        <button 
                          onClick={() => handleDownloadPfx(client)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 text-amber-700 rounded-full text-[10px] font-bold uppercase tracking-wider hover:bg-amber-100 transition-all border border-amber-100/50"
                          title="PFX imzoni yuklab olish"
                        >
                          <Download className="w-3 h-3" />
                          PFX
                        </button>
                      )}
                      <button className="p-2 text-[#A89F8E] hover:text-[#5A5A40] transition-colors">
                        <Mail className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-[#A89F8E] hover:text-[#5A5A40] transition-colors">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
