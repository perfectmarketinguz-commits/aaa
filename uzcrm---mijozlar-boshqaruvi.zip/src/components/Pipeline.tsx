import { 
  ChevronRight, 
  Circle, 
  Star, 
  MoreHorizontal,
  Plus
} from 'lucide-react';
import { Deal } from '../types';
import { cn } from '../lib/utils';

const STAGES = {
  negotiation: 'Muzokara',
  proposal: 'Taklif',
  contract: 'Shartnoma',
  closed: 'Yakunlangan'
} as const;

const initialDeals: Deal[] = [
  { id: '1', title: 'Korporativ veb-sayt', clientId: '1', clientName: 'Najot Ta\'lim', value: 5000, stage: 'negotiation', priority: 'high', updatedAt: '2 kun oldin' },
  { id: '2', title: 'Mobil ilova dizayni', clientId: '2', clientName: 'PDP Academy', value: 3500, stage: 'proposal', priority: 'medium', updatedAt: 'Bugun' },
  { id: '3', title: 'SEO optimizatsiya', clientId: '3', clientName: 'IT Park', value: 1200, stage: 'negotiation', priority: 'low', updatedAt: '1 soat oldin' },
  { id: '4', title: 'CRM Tizimi', clientId: '4', clientName: 'Ucell', value: 12000, stage: 'contract', priority: 'high', updatedAt: '3 kun oldin' },
  { id: '5', title: 'SMM Xizmatlari', clientId: '5', clientName: 'Beeline', value: 800, stage: 'closed', priority: 'medium', updatedAt: '5 kun oldin' },
];

interface PipelineProps {
  deals: Deal[];
  onAddClick: () => void;
}

export function Pipeline({ deals, onAddClick }: PipelineProps) {
  const renderColumn = (stage: keyof typeof STAGES) => {
    const dealsInStage = deals.filter(d => d.stage === stage);
    const totalValue = dealsInStage.reduce((acc, curr) => acc + curr.value, 0);

    return (
      <div key={stage} className="flex flex-col gap-6 min-w-[320px]">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-3">
            <h3 className="font-serif text-lg text-[#2D3025]">{STAGES[stage]}</h3>
            <span className="text-[10px] uppercase tracking-widest font-bold bg-[#EAEAE2] text-[#5A5A40] px-2 py-0.5 rounded-full">
              {dealsInStage.length}
            </span>
          </div>
          <span className="text-sm font-semibold text-[#5A5A40] italic">${totalValue.toLocaleString()}</span>
        </div>

        <div className="space-y-4">
          {dealsInStage.map(deal => (
            <div 
              key={deal.id} 
              className="bg-white p-6 rounded-[24px] shadow-sm border border-[#D9D9D0] hover:border-[#5A5A40] transition-all cursor-grab active:cursor-grabbing group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="text-[#A89F8E] hover:text-[#5A5A40]">
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>
              
              <h4 className="text-sm font-bold text-[#2D3025] mb-1 group-hover:text-[#5A5A40] transition-colors pr-6">
                {deal.title}
              </h4>
              <p className="text-[11px] text-[#A89F8E] uppercase tracking-widest mb-6">{deal.clientName}</p>
              
              <div className="flex items-center justify-between pt-4 border-t border-[#F5F5F0]">
                <span className="text-lg font-serif tracking-tight text-[#2D3025]">${deal.value.toLocaleString()}</span>
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full",
                    deal.priority === 'high' ? "bg-rose-50 text-rose-600" :
                    deal.priority === 'medium' ? "bg-amber-50 text-amber-600" : "bg-emerald-50 text-green-600"
                  )}>
                    {deal.priority === 'high' ? 'Tezkor' : 
                     deal.priority === 'medium' ? 'O\'rta' : 'Past'}
                  </span>
                </div>
              </div>
            </div>
          ))}
          <button 
            onClick={onAddClick}
            className="w-full py-4 border border-dashed border-[#A89F8E] rounded-[24px] text-[#A89F8E] hover:text-[#5A5A40] hover:bg-white transition-all flex items-center justify-center gap-2 text-sm font-medium italic"
          >
            <Plus className="w-4 h-4" />
            Yangi bitim
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex items-center justify-between mb-10">
        <div>
          <h2 className="text-3xl font-serif text-[#2D3025]">Kelishuvlar</h2>
          <p className="text-[#5A5A40] italic">Sotuv voronkasi bo'yicha joriy holat.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={onAddClick}
            className="bg-[#5A5A40] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#454530] transition-all whitespace-nowrap shadow-lg shadow-[#5A5A40]/10"
          >
            + Yangi Bitim
          </button>
        </div>
      </div>

      <div className="flex gap-10 overflow-x-auto pb-12 scrollbar-hide">
        {(Object.keys(STAGES) as (keyof typeof STAGES)[]).map(renderColumn)}
      </div>
    </div>
  );
}
