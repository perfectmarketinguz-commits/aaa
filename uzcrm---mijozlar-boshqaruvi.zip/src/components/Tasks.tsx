import { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  Plus, 
  Calendar,
  AlertCircle
} from 'lucide-react';
import { Task } from '../types';
import { cn } from '../lib/utils';

const initialTasks: Task[] = [
  { id: '1', title: 'Mijoz bilan uchrashuv', description: 'Ali Valiev bilan shartnomani muhokama qilish', dueDate: 'Bugun, 14:00', completed: false, priority: 'high' },
  { id: '2', title: 'Veb-sayt dizaynini taqdim etish', description: 'Bosh sahifa variantlarini yuborish', dueDate: 'Ertaga, 10:00', completed: true, priority: 'medium' },
  { id: '3', title: 'Lidlarni saralash', description: 'Yangi lidlar bilan bog\'lanish', dueDate: '25-mart', completed: false, priority: 'low' },
  { id: '4', title: 'Xisobot tayyorlash', description: 'Mart oyi uchun tahliliy hisobot', dueDate: '30-mart', completed: false, priority: 'high' },
];

import { toggleTask as fbToggleTask } from '../services/dbService';

interface TasksProps {
  tasks: Task[];
}

export function Tasks({ tasks }: TasksProps) {
  const toggleTask = (id: string, currentStatus: boolean) => {
    fbToggleTask(id, !currentStatus);
  };

  return (
    <div className="animate-in fade-in duration-500 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Vazifalar</h1>
          <p className="text-slate-500 mt-1">Sifatli ish jarayoni uchun rejalashtirilgan ishlar.</p>
        </div>
        <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2.5 rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20 font-medium">
          <Plus className="w-5 h-5" />
          Yangi vazifa
        </button>
      </div>

      <div className="space-y-4">
        {tasks.map((task) => (
          <div 
            key={task.id}
            className={cn(
              "group bg-white p-5 rounded-2xl border transition-all duration-200 flex items-start gap-4",
              task.completed ? "border-slate-100 opacity-60" : "border-slate-100 hover:border-indigo-200 shadow-sm"
            )}
          >
            <button 
              onClick={() => toggleTask(task.id, task.completed)}
              className="mt-1 flex-shrink-0"
            >
              {task.completed ? (
                <CheckCircle2 className="w-6 h-6 text-indigo-500 fill-indigo-50" />
              ) : (
                <Circle className="w-6 h-6 text-slate-300 group-hover:text-indigo-400 transition-colors" />
              )}
            </button>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-4 mb-1">
                <h3 className={cn(
                  "text-base font-semibold truncate",
                  task.completed ? "text-slate-400 line-through" : "text-slate-900"
                )}>
                  {task.title}
                </h3>
                <div className={cn(
                  "flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded",
                  task.priority === 'high' ? "text-rose-600 bg-rose-50" :
                  task.priority === 'medium' ? "text-amber-600 bg-amber-50" : "text-emerald-600 bg-emerald-50"
                )}>
                  {task.priority === 'high' ? 'Tezkor' : 
                   task.priority === 'medium' ? 'O\'rta' : 'Past'}
                </div>
              </div>
              <p className="text-sm text-slate-500 mb-4">{task.description}</p>
              
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                  <Clock className="w-3.5 h-3.5" />
                  {task.dueDate}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                  <Calendar className="w-3.5 h-3.5" />
                  Muddati tugashiga 2 kun qoldi
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
