import React, { useState, useEffect } from 'react';
import { UserPlus, Shield, Mail, Calendar, Trash2 } from 'lucide-react';
import { subscribeToUsers, addUserToDb } from '../services/dbService';
import { cn } from '../lib/utils';

export function Users() {
  const [users, setUsers] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'staff'
  });

  useEffect(() => {
    const unsub = subscribeToUsers(setUsers);
    return () => unsub();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addUserToDb(formData);
      setFormData({ name: '', email: '', role: 'staff' });
      setIsAdding(false);
    } catch (err) {
      console.error(err);
      alert("Xatolik: Foydalanuvchini qo'shish imkoni bo'lmadi.");
    }
  };

  return (
    <div className="animate-in fade-in duration-500 space-y-10">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div>
          <h2 className="text-3xl font-serif text-[#2D3025]">Foydalanuvchilar</h2>
          <p className="text-[#5A5A40] italic">Tizimga kirish huquqiga ega xodimlar ro'yxati.</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-[#5A5A40] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#454530] transition-all flex items-center gap-2 shadow-lg shadow-[#5A5A40]/10"
        >
          <UserPlus className="w-4 h-4" />
          {isAdding ? "Bekor qilish" : "Yangi Foydalanuvchi"}
        </button>
      </header>

      {isAdding && (
        <div className="bg-white p-8 rounded-[32px] shadow-sm border border-[#D9D9D0] animate-in slide-in-from-top-4 duration-300">
          <h3 className="font-serif text-xl mb-6 text-[#2D3025]">Yangi xodim qo'shish</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">F.I.O</label>
              <input 
                required
                type="text" 
                placeholder="Ism Familiya"
                className="w-full bg-[#EAEAE2] border-none rounded-2xl px-6 py-3 text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none text-[#2D3025]"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">Email</label>
              <input 
                required
                type="email" 
                placeholder="example@gmail.com"
                className="w-full bg-[#EAEAE2] border-none rounded-2xl px-6 py-3 text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none text-[#2D3025]"
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-[#5A5A40] ml-1">Rol</label>
              <div className="flex gap-4">
                <select 
                  className="flex-1 bg-[#EAEAE2] border-none rounded-2xl px-6 py-3 text-sm focus:ring-1 focus:ring-[#5A5A40] outline-none text-[#2D3025] appearance-none"
                  value={formData.role}
                  onChange={e => setFormData({...formData, role: e.target.value})}
                >
                  <option value="staff">Xodim</option>
                  <option value="admin">Administrator</option>
                </select>
                <button 
                  type="submit"
                  className="bg-[#5A5A40] text-white px-8 py-3 rounded-2xl text-sm font-medium hover:bg-[#454530] transition-all"
                >
                  Qo'shish
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-[32px] shadow-sm border border-[#D9D9D0] overflow-hidden">
        <div className="overflow-x-auto p-2">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] uppercase tracking-widest text-[#5A5A40] border-b border-[#F5F5F0]">
                <th className="px-6 py-4 font-semibold">Foydalanuvchi</th>
                <th className="px-6 py-4 font-semibold">Rol</th>
                <th className="px-6 py-4 font-semibold">Email</th>
                <th className="px-6 py-4 font-semibold text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {users.map((user) => (
                <tr key={user.id} className="border-b border-[#F5F5F0] hover:bg-[#F5F5F0]/30 transition-colors group">
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#A89F8E] flex items-center justify-center text-[#2D3025] font-bold text-xs">
                        {user.name?.split(' ').map((n:any) => n[0]).join('')}
                      </div>
                      <span className="font-semibold text-[#2D3025]">{user.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest",
                      user.role === 'admin' ? "bg-amber-50 text-amber-600" : "bg-blue-50 text-blue-600"
                    )}>
                      {user.role === 'admin' ? 'Administrator' : 'Xodim'}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-[#5A5A40]">
                    {user.email}
                  </td>
                  <td className="px-6 py-5 text-right">
                    <button className="p-2 text-[#A89F8E] hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
