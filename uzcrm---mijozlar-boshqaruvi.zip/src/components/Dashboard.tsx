import { 
  Users, 
  DollarSign, 
  Target, 
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Search
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

const data = [
  { name: 'Yan', leads: 40, deals: 24, amt: 2400 },
  { name: 'Fev', leads: 30, deals: 13, amt: 2210 },
  { name: 'Mar', leads: 20, deals: 98, amt: 2290 },
  { name: 'Apr', leads: 27, deals: 39, amt: 2000 },
  { name: 'May', leads: 18, deals: 48, amt: 2181 },
  { name: 'Iyun', leads: 23, deals: 38, amt: 2500 },
];

const revenueData = [
  { day: 'Dushanba', revenue: 4000 },
  { day: 'Seshanba', revenue: 3000 },
  { day: 'Chorshanba', revenue: 5000 },
  { day: 'Payshanba', revenue: 2780 },
  { day: 'Juma', revenue: 1890 },
  { day: 'Shanba', revenue: 2390 },
  { day: 'Yakshanba', revenue: 3490 },
];

const StatCard = ({ title, value, subValue, trend, isDark }: any) => (
  <div className={cn(
    "rounded-[32px] p-6 shadow-sm border",
    isDark ? "bg-[#5A5A40] text-white border-[#5A5A40]" : "bg-white border-[#D9D9D0] text-[#2D3025]"
  )}>
    <p className={cn(
      "text-[10px] uppercase tracking-widest mb-2 font-medium",
      isDark ? "opacity-70" : "text-[#5A5A40]"
    )}>
      {title}
    </p>
    <h3 className="text-3xl font-serif tracking-tight">{value}</h3>
    <div className={cn(
      "mt-4 flex items-center text-xs font-medium",
      isDark ? "opacity-70" : trend > 0 ? "text-green-600" : "text-[#5A5A40]"
    )}>
      {trend ? (
        <>
          <span>{trend > 0 ? '+' : ''}{trend}% o'sish</span>
          <div className={cn("ml-2 w-8 h-px", isDark ? "bg-white" : trend > 0 ? "bg-green-600" : "bg-[#5A5A40]")}></div>
        </>
      ) : (
        <span>{subValue}</span>
      )}
    </div>
  </div>
);

import { cn } from '../lib/utils';

export function Dashboard({ onAddClick, clientsCount }: { onAddClick: () => void, clientsCount: number }) {
  return (
    <div className="animate-in fade-in duration-500 space-y-10">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div>
          <h2 className="text-3xl font-serif text-[#2D3025]">Asosiy Ko'rsatkichlar</h2>
          <p className="text-[#5A5A40] italic">Bugun, 24-May, 2024 yil</p>
        </div>
        <div className="flex gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A89F8E]" />
            <input type="text" placeholder="Qidiruv..." className="bg-[#EAEAE2] border-none rounded-full px-11 py-2 text-sm w-full focus:ring-1 focus:ring-[#5A5A40] outline-none placeholder:opacity-50 text-[#2D3025]">
            </input>
          </div>
          <button 
            onClick={onAddClick}
            className="bg-[#5A5A40] text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-[#454530] transition-all whitespace-nowrap shadow-lg shadow-[#5A5A40]/10"
          >
            + Yangi Mijoz
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Jami mijozlar" value={clientsCount.toLocaleString()} trend={8.2} />
        <StatCard title="Oylik tushum" value="$45,210" trend={12.5} />
        <StatCard title="Yangi bitimlar" value="48" subValue="Trend: Yuqori" />
        <StatCard title="Konversiya" value="24.8%" trend={4.1} isDark />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-[32px] shadow-sm border border-[#D9D9D0]">
          <h4 className="font-serif text-xl mb-6 text-[#2D3025]">Mijozlar faolligi</h4>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F5F5F0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#A89F8E', textTransform: 'uppercase', letterSpacing: '0.1em' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#A89F8E' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#2D3025', borderRadius: '12px', border: 'none', color: '#F5F5F0' }}
                  itemStyle={{ color: '#F5F5F0' }}
                  cursor={{ fill: '#F5F5F0' }}
                />
                <Bar dataKey="leads" fill="#5A5A40" radius={[4, 4, 0, 0]} barSize={20} />
                <Bar dataKey="deals" fill="#A89F8E" radius={[4, 4, 0, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] shadow-sm border border-[#D9D9D0]">
          <h4 className="font-serif text-xl mb-6 text-[#2D3025]">Daromad tahlili</h4>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#5A5A40" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#5A5A40" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F5F5F0" />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#A89F8E', textTransform: 'uppercase', letterSpacing: '0.1em' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#A89F8E' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#2D3025', borderRadius: '12px', border: 'none', color: '#F5F5F0' }}
                  itemStyle={{ color: '#F5F5F0' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#5A5A40" fillOpacity={1} fill="url(#colorRev)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
