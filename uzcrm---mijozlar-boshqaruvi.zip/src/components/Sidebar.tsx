import { 
  Users, 
  LayoutDashboard, 
  Briefcase, 
  CheckSquare, 
  Settings,
  LogOut,
  TrendingUp,
  Shield
} from 'lucide-react';
import { cn } from '../lib/utils';
import { View } from '../types';
import { AppUser, logout } from '../services/authService';

interface SidebarProps {
  currentView: View;
  onViewChange: (view: View) => void;
  user: AppUser;
}

const navItems = [
  { id: 'dashboard', label: 'Boshqaruv', icon: LayoutDashboard },
  { id: 'clients', label: 'Mijozlar', icon: Users },
  { id: 'pipeline', label: 'Bitimlar', icon: Briefcase },
  { id: 'tasks', label: 'Vazifalar', icon: CheckSquare },
  { id: 'users', label: 'Xodimlar', icon: Shield, adminOnly: true },
] as const;

export function Sidebar({ currentView, onViewChange, user }: SidebarProps) {
  const initials = user.displayName
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase();

  const filteredNavItems = navItems.filter(item => !('adminOnly' in item) || user.role === 'admin');

  return (
    <aside className="w-64 bg-[#2D3025] text-[#F5F5F0] h-screen flex flex-col fixed left-0 top-0 p-8 shadow-2xl z-50">
      <div className="flex items-center gap-3 mb-12">
        <div className="w-8 h-8 rounded-full bg-[#5A5A40] border border-[#F5F5F0]/20 flex items-center justify-center font-serif italic text-lg">
          V
        </div>
        <span className="text-xl font-serif tracking-tight">UzCRM</span>
      </div>

      <nav className="flex-1 space-y-6">
        {filteredNavItems.map((item, index) => {
          return (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id as View)}
              className={cn(
                "w-full flex items-center gap-4 transition-all duration-200 group text-sm font-medium",
                currentView === item.id 
                  ? "text-[#F5F5F0]" 
                  : "text-[#F5F5F0]/60 hover:text-[#F5F5F0]"
              )}
            >
              <span className="opacity-40 text-[10px] uppercase tracking-widest min-w-[20px]">
                0{index + 1}
              </span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="pt-8 border-t border-[#F5F5F0]/10 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#A89F8E] flex items-center justify-center text-[#2D3025] font-bold text-xs">
            {initials}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-[#F5F5F0] truncate">{user.displayName}</p>
            <p className="text-[10px] uppercase opacity-50">{user.role === 'admin' ? 'Administrator' : 'Xodim'}</p>
          </div>
        </div>
        <button className="flex items-center gap-2 text-[#F5F5F0]/40 hover:text-[#F5F5F0]/60 transition-colors text-xs font-medium uppercase tracking-widest group">
          <Settings className="w-3.5 h-3.5 group-hover:rotate-45 transition-transform" />
          Sozlamalar
        </button>
        <button 
          onClick={() => logout()}
          className="flex items-center gap-2 text-rose-400/60 hover:text-rose-400 transition-colors text-xs font-medium uppercase tracking-widest"
        >
          <LogOut className="w-3.5 h-3.5" />
          Chiqish
        </button>
      </div>
    </aside>
  );
}
