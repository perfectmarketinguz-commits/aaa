export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  status: 'active' | 'inactive' | 'lead';
  createdAt: string;
  pfxData?: string; // Base64 encoded file content
  pfxFileName?: string;
}

export interface Deal {
  id: string;
  title: string;
  clientId: string;
  clientName: string;
  value: number;
  stage: 'negotiation' | 'proposal' | 'contract' | 'closed';
  priority: 'low' | 'medium' | 'high';
  updatedAt: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
}

export type View = 'dashboard' | 'clients' | 'pipeline' | 'tasks' | 'users';
