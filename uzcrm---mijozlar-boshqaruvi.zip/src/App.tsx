/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Clients } from './components/Clients';
import { Pipeline } from './components/Pipeline';
import { Tasks } from './components/Tasks';
import { View, Client, Deal, Task } from './types';
import { auth } from './lib/firebase';
import { checkUserAuthorization, AppUser } from './services/authService';
import { LoginPage } from './components/LoginPage';
import { AddClientModal } from './components/AddClientModal';
import { Users as UsersView } from './components/Users';
import { 
  subscribeToClients, 
  subscribeToDeals, 
  subscribeToTasks, 
  addClient 
} from './services/dbService';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [user, setUser] = useState<AppUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | undefined>();
  
  const [clients, setClients] = useState<Client[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const authorizedUser = await checkUserAuthorization(fbUser);
          if (authorizedUser) {
            setUser(authorizedUser);
            setError(undefined);
          } else {
            setUser(null);
            setError("Kechirasiz, sizga tizimga kirish uchun ruxsat berilmagan. Administrator bilan bog'laning.");
          }
        } catch (err) {
          console.error(err);
          setError("Auth xatosi yuz berdi.");
        }
      } else {
        setUser(null);
      }
      setIsLoading(false);
    });

    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (!user) return;

    const unsubClients = subscribeToClients(setClients);
    const unsubDeals = subscribeToDeals(setDeals);
    const unsubTasks = subscribeToTasks(setTasks);

    return () => {
      unsubClients();
      unsubDeals();
      unsubTasks();
    };
  }, [user]);

  const handleAddClient = async (clientData: Omit<Client, 'id' | 'createdAt' | 'phone'>) => {
    try {
      await addClient({
        ...clientData,
        phone: '+998 00 000 00 00'
      });
    } catch (err) {
      console.error(err);
      alert("Xatolik yuz berdi");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-[#5A5A40] border-t-transparent rounded-full animate-spin"></div>
          <p className="font-serif italic text-[#5A5A40]">Yuklanmoqda...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage error={error} />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onAddClick={() => setIsAddModalOpen(true)} clientsCount={clients.length} />;
      case 'clients':
        return <Clients clients={clients} onAddClick={() => setIsAddModalOpen(true)} />;
      case 'pipeline':
        return <Pipeline onAddClick={() => setIsAddModalOpen(true)} deals={deals} />;
      case 'tasks':
        return <Tasks tasks={tasks} />;
      case 'users':
        return <UsersView />;
      default:
        return <Dashboard onAddClick={() => setIsAddModalOpen(true)} clientsCount={clients.length} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] font-sans text-[#2D3025]">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} user={user} />
      
      <main className="ml-64 min-h-screen flex flex-col p-10">
        <div className="flex-1">
          {renderView()}
        </div>
      </main>

      <AddClientModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
        onAdd={handleAddClient} 
      />
    </div>
  );
}
