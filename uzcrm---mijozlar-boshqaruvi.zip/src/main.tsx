import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { doc, getDocFromServer } from 'firebase/firestore';
import { db } from './lib/firebase';

// Test Firestore connection
async function testConnection() {
  try {
    // We don't necessarily need permission to this doc, 
    // we just want to see if the network request reaches the server.
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error: any) {
    if (error?.code === 'unavailable') {
      console.error("Firestore is unavailable. Please check your internet connection or firewall.");
    } else {
      console.log("Firestore connection check:", error?.code || error?.message);
    }
  }
}

testConnection();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
